﻿namespace CGEditor.CGItemWrappers
{
    class Shape
    {
    }
}
