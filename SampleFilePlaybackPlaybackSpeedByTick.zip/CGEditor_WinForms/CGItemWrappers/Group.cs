﻿using System.ComponentModel;


namespace CGEditor.CGItemWrappers
{
    [DisplayName("Group Item Properties")]
    public class CGGroupItem : CGBaseItem
    {
        public CGGroupItem(string itemId) : base(itemId) { }

    }
}
