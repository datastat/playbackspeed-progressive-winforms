﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CGEditor.CGItemWrappers
{
    public interface ITickerNewContent
    {
        string NewContent { get; set; }
    }
}
