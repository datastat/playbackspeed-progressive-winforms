﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CGEditor.CGItemWrappers
{
    public interface ISpeed
    {
        double SpeedX { get; set; }
        double SpeedY { get; set; }
    }
}
